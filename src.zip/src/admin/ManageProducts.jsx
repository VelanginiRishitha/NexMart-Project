import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../config';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../admin/admincss/product.css';

const ManageProducts = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await axios.get(`${config.url}/product/viewallproducts`);
      setProducts(res.data);
    } catch (err) {
      toast.error('Error loading products');
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${config.url}/admin/deleteproduct?pid=${id}`);
      setProducts(prev => prev.filter(p => p.id !== id));
      toast.success('Product deleted successfully');
    } catch (err) {
      toast.error('Error deleting product');
    }
  };

  return (
    <div className="product-table-container">
      <h2 className="product-heading">Manage Products</h2>
      {products.length === 0 ? (
        <p className="no-products">No products available</p>
      ) : (
        <table className="product-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Description</th>
              <th>Cost</th>
              <th>Farmer Details</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => (
              <tr key={p.id}>
                <td>
                  <img
                    src={`${config.url}/product/displayproductimage?id=${p.id}`}
                    alt={p.name}
                    className="product-image"
                  />
                </td>
                <td>{p.name}</td>
                <td>{p.description}</td>
                <td>₹{p.cost}</td>
                <td>
                  <p><strong>Username:</strong> {p.farmer ? p.farmer.username : 'N/A'}</p>
                  <p><strong>Gmail:</strong> {p.farmer ? p.farmer.gmail : 'N/A'}</p>
                </td>
                <td>
                  <button className="delete-btn" onClick={() => handleDelete(p.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <ToastContainer position="top-center" />
    </div>
  );
};

export default ManageProducts;
