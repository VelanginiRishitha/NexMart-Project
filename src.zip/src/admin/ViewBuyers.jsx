import { useEffect, useState } from "react";
import axios from "axios";
import config from "../config";

import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';

export default function ViewBuyers() 
{
    const [buyers, setBuyers] = useState([]);
    const [error, setError] = useState("");

    const displayBuyers = async () => 
    {
        try 
        {
            const response = await axios.get(`${config.url}/admin/viewallbuyers`);
            setBuyers(response.data);
        } 
        catch (err) 
        {
            setError("Failed to fetch buyers data ... " + err.message);
        }
    };

    useEffect(() => {
        displayBuyers();
    }, []);

    const deleteBuyer = async (bid) => 
    {
        try 
       {
            const response = await axios.delete(`${config.url}/admin/deletebuyer?bid=${bid}`);
            alert(response.data);
            displayBuyers();
        } 
        catch (err) 
        {
            setError("Unexpected Error Occurred... " + err.message);
        }
    };

    return (
        <div style={{ padding: "20px" }}>
            <h3 style={{ textAlign: "center", color: "black", fontWeight: "bolder" }}>
                <u>View All Buyers</u>
            </h3>

            {error ? (
                <p style={{ textAlign: "center", fontSize: "18px", fontWeight: "bold", color: "red" }}>
                    {error}
                </p>
            ) : buyers.length === 0 ? (
                <p style={{ textAlign: "center", fontSize: "18px", fontWeight: "bold", color: "red" }}>
                    No Buyer Data Found
                </p>
            ) : (
                <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "20px" }}>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>DOB</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Mobile No</th>
                            <th>Location</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {buyers.map((buyer) => (
                            <tr key={buyer.id}>
                                <td>{buyer.id}</td>
                                <td>{buyer.name}</td>
                                <td>{buyer.gender}</td>
                                <td>{buyer.dob}</td>
                                <td>{buyer.email}</td>
                                <td>{buyer.username}</td>
                                <td>{buyer.mobileno}</td>
                                <td>{buyer.location}</td>
                                
                                <td>
       <Button variant="outlined" startIcon={<DeleteIcon/>}  onClick={() => deleteBuyer(buyer.id)}>
        Delete
      </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}