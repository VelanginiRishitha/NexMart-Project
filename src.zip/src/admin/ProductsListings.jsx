import React from 'react'

export default function ProductsListings() {
  return (
    <div>
      
    </div>
  )
}
