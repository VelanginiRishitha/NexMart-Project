//import React from 'react'

export default function Contact() 
{
  return (
    <div>
        <h4>I am in Contact Page</h4>
    </div>
  )
}
