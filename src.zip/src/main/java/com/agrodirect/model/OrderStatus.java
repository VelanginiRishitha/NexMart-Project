package com.agrodirect.model;

public enum OrderStatus {
    PENDING,
    COMPLETED,
    CANCELLED
} 