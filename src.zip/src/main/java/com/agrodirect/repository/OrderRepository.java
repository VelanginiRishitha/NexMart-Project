package com.agrodirect.repository;

import com.agrodirect.model.Order;
import com.agrodirect.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByFarmerIdAndStatus(Long farmerId, OrderStatus status);
    
    List<Order> findByFarmerId(Long farmerId);
    
    @Query("SELECT o FROM Order o WHERE o.farmer.id = :farmerId AND o.orderDate BETWEEN :startDate AND :endDate")
    List<Order> findByFarmerIdAndDateRange(
        @Param("farmerId") Long farmerId,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate
    );
    
    @Query("SELECT SUM(o.total) FROM Order o WHERE o.farmer.id = :farmerId AND o.status = 'COMPLETED'")
    Double getTotalSalesByFarmerId(@Param("farmerId") Long farmerId);
    
    @Query("SELECT COUNT(o) FROM Order o WHERE o.farmer.id = :farmerId AND o.status = 'COMPLETED'")
    Integer getTotalOrdersByFarmerId(@Param("farmerId") Long farmerId);
} 