package com.agrodirect.dto;

import lombok.Data;

@Data
public class OrderItemDTO {
    private Long id;
    private String productName;
    private String imageUrl;
    private Integer quantity;
    private Double price;
    private Double subtotal;
} 