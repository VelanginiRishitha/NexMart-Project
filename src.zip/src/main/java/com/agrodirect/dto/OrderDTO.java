package com.agrodirect.dto;

import com.agrodirect.model.OrderStatus;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderDTO {
    private Long id;
    private String customerName;
    private String customerPhone;
    private String deliveryAddress;
    private List<OrderItemDTO> items;
    private Double subtotal;
    private Double deliveryFee;
    private Double total;
    private OrderStatus status;
    private LocalDateTime orderDate;
} 