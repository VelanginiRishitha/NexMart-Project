package com.agrodirect.dto;

import lombok.Data;
import java.util.List;

@Data
public class SalesReportDTO {
    private Double totalSales;
    private Integer totalOrders;
    private Double averageOrderValue;
    private List<TopSellingProductDTO> topSellingProducts;
    private List<CategorySalesDTO> salesByCategory;
    private List<TransactionDTO> recentTransactions;
}

@Data
class TopSellingProductDTO {
    private Long id;
    private String name;
    private String imageUrl;
    private Integer unitsSold;
    private Double revenue;
}

@Data
class CategorySalesDTO {
    private String name;
    private Double sales;
}

@Data
class TransactionDTO {
    private Long id;
    private Long orderId;
    private String date;
    private Double amount;
    private String status;
} 