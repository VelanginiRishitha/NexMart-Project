package com.agrodirect.service;

import com.agrodirect.dto.*;
import com.agrodirect.model.*;
import com.agrodirect.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FarmerService {
    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private ProductRepository productRepository;

    public List<OrderDTO> getFarmerOrders(Long farmerId) {
        List<Order> orders = orderRepository.findByFarmerId(farmerId);
        return orders.stream()
            .map(this::convertToOrderDTO)
            .collect(Collectors.toList());
    }

    public List<OrderDTO> getFarmerOrdersByStatus(Long farmerId, OrderStatus status) {
        List<Order> orders = orderRepository.findByFarmerIdAndStatus(farmerId, status);
        return orders.stream()
            .map(this::convertToOrderDTO)
            .collect(Collectors.toList());
    }

    public void updateOrderStatus(Long orderId, OrderStatus status) {
        Order order = orderRepository.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(status);
        orderRepository.save(order);
    }

    public SalesReportDTO getSalesReport(Long farmerId, LocalDateTime startDate, LocalDateTime endDate) {
        List<Order> orders = orderRepository.findByFarmerIdAndDateRange(farmerId, startDate, endDate);
        
        SalesReportDTO report = new SalesReportDTO();
        report.setTotalSales(calculateTotalSales(orders));
        report.setTotalOrders(orders.size());
        report.setAverageOrderValue(calculateAverageOrderValue(orders));
        report.setTopSellingProducts(getTopSellingProducts(orders));
        report.setSalesByCategory(getSalesByCategory(orders));
        report.setRecentTransactions(getRecentTransactions(orders));
        
        return report;
    }

    private OrderDTO convertToOrderDTO(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setId(order.getId());
        dto.setCustomerName(order.getCustomerName());
        dto.setCustomerPhone(order.getCustomerPhone());
        dto.setDeliveryAddress(order.getDeliveryAddress());
        dto.setSubtotal(order.getSubtotal());
        dto.setDeliveryFee(order.getDeliveryFee());
        dto.setTotal(order.getTotal());
        dto.setStatus(order.getStatus());
        dto.setOrderDate(order.getOrderDate());
        
        dto.setItems(order.getItems().stream()
            .map(this::convertToOrderItemDTO)
            .collect(Collectors.toList()));
            
        return dto;
    }

    private OrderItemDTO convertToOrderItemDTO(OrderItem item) {
        OrderItemDTO dto = new OrderItemDTO();
        dto.setId(item.getId());
        dto.setProductName(item.getProduct().getName());
        dto.setImageUrl(item.getProduct().getImageUrl());
        dto.setQuantity(item.getQuantity());
        dto.setPrice(item.getPrice());
        dto.setSubtotal(item.getSubtotal());
        return dto;
    }

    private Double calculateTotalSales(List<Order> orders) {
        return orders.stream()
            .filter(order -> order.getStatus() == OrderStatus.COMPLETED)
            .mapToDouble(Order::getTotal)
            .sum();
    }

    private Double calculateAverageOrderValue(List<Order> orders) {
        List<Order> completedOrders = orders.stream()
            .filter(order -> order.getStatus() == OrderStatus.COMPLETED)
            .collect(Collectors.toList());
            
        if (completedOrders.isEmpty()) {
            return 0.0;
        }
        
        return calculateTotalSales(completedOrders) / completedOrders.size();
    }

    private List<TopSellingProductDTO> getTopSellingProducts(List<Order> orders) {
        // Implementation to calculate top selling products
        // This would typically involve grouping and aggregating order items
        return null; // TODO: Implement this method
    }

    private List<CategorySalesDTO> getSalesByCategory(List<Order> orders) {
        // Implementation to calculate sales by category
        // This would typically involve grouping and aggregating order items by category
        return null; // TODO: Implement this method
    }

    private List<TransactionDTO> getRecentTransactions(List<Order> orders) {
        return orders.stream()
            .map(order -> {
                TransactionDTO dto = new TransactionDTO();
                dto.setId(order.getId());
                dto.setOrderId(order.getId());
                dto.setDate(order.getOrderDate().toString());
                dto.setAmount(order.getTotal());
                dto.setStatus(order.getStatus().toString());
                return dto;
            })
            .collect(Collectors.toList());
    }
} 