import React from 'react';
import image from './image.png';

 

export default function Home() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', padding: '20px' }}>
      {/* Left Side - Image */}
      <div style={{ flex: 1, textAlign: 'center' }}>
        <img src={image} alt="Agriculture" style={{ width: '100%', borderRadius: '10px' }} />
      </div>
      
      {/* Right Side - Text */}
      <div style={{ flex: 1, textAlign: 'left', padding: '30px' }}>
        <h1 style={{ fontWeight: 'bold' }}>
           Welcome to AgroDirect <br />
          A Farmer-Friendly Marketplace! 🌱
        </h1>
        <br />
        <p>🚜 For Farmers – Sell your harvest directly and maximize profits.</p>
        <p>🛒 For Buyers – Get fresh, high-quality produce straight from farms.</p>
        <br />
        <p style={{ fontWeight: 'bold' }}>Start your journey today! 🎊 Buy | Sell | Grow Together</p>
        <br />
        <button style={{ backgroundColor: '#28a745', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '5px', fontSize: '16px', cursor: 'pointer' }}>
          Join Now
        </button>
      </div>
    </div>
  );
}
