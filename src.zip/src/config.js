const config = 
{
    "url":"http://localhost:2020"
}

export default config