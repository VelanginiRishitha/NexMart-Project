import { Routes, Route, Link, NavLink } from 'react-router-dom';
import { FaHome, FaTachometerAlt, FaShoppingCart, FaClipboardList, FaMoneyBillWave, FaInfoCircle, FaBoxOpen, FaUser ,FaSignOutAlt} from 'react-icons/fa';
import Contact from './../main/Contact';
import Menu from './../main/menu';
import NotFound from './../main/NotFound';
import About from './../main/About';
import Dashboard from './Dashboard';
import Orders from './Orders';
import FarmerHome from './FarmerHome';
import AddProducts from './AddProducts';
import MyListings from './MyListings';
import Transactions from './../buyer/Transactions';
import SalesReport from './SalesReport';
import './Farmer.css'; 
 import { useAuth } from '../contextapi/AuthContext';
import FarmerProfile from './FarmerProfile';
import logo from '../assets/logo.png';

export default function FarmerNavBar() {
  const { setIsFarmerLoggedIn } = useAuth(); 

  const handleLogout = () => {
    setIsFarmerLoggedIn(false);
    sessionStorage.clear();
  };

  return (
    <div className="app-container">
      <nav className="navbar">
        <div className="logo" style={{ display: 'flex', alignItems: 'center' }}>
          <img src={logo} alt="Logo" style={{ height: '40px', width: '40px', marginRight: '8px', borderRadius: '50%' }} />
          <h1 style={{ fontSize: '24px', color: 'white' }}><strong>AgroDirect</strong></h1>
        </div>

        <div className="profile-link">
          <ul>
            <li>
              <Link to="/farmerprofile" style={{ display: 'flex', alignItems: 'center' }}>
                <div style={{
                  backgroundColor: '#fff',
                  borderRadius: '50%',
                  padding: '6px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: '8px',
                  width: '30px',
                  height: '30px'
                }}>
                  <FaUser color="black" />
                </div>
                MyProfile
              </Link>
            </li>
          </ul>
        </div>
      </nav>

      <div className="main-content">
        <aside className="sidebar">
          <h2 className="sidebar-heading">Menu</h2>
          <ul>
            <li><NavLink to="/farmerhome"><FaHome /> Home</NavLink></li>
            <li><NavLink to="/dashboard"><FaTachometerAlt /> Dashboard</NavLink></li>
            <li><NavLink to="/addproducts"><FaBoxOpen /> Add Products</NavLink></li>
            <li><NavLink to="/salesreport"><FaClipboardList /> Sales Report</NavLink></li>
            <li><NavLink to="/orders"><FaShoppingCart /> Orders</NavLink></li>
            <li><NavLink to="/transactions"><FaMoneyBillWave /> Transactions</NavLink></li>
            <li><NavLink to="/about"><FaInfoCircle /> About Us</NavLink></li>
             <li><Link to="/farmerlogin" onClick={handleLogout}> <FaSignOutAlt />Logout</Link></li>
  
 

          </ul>
        </aside>

        <main className="content">
          <Routes>
            <Route path="/farmerhome" element={<FarmerHome />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/salesreport" element={<SalesReport />} />
            <Route path="/menu" element={<Menu />} />
            <Route path="/mylistings" element={<MyListings />} />
            <Route path="/addproducts" element={<AddProducts />} />
            <Route path="/transactions" element={<Transactions />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/farmerprofile" element={<FarmerProfile />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
