import React from 'react';

export default function FarmerHome() {
  return (
    <div style={{ textAlign: 'center', fontWeight: 'bold' }}>
      <h1>
        Welcome to <big>AgroDirect</big> <br /> <br />
        Fresh Produce, Direct from Farms to Your Doorstep!
      </h1>
      <br />
      <br />
      <h3>
        Welcome to a seamless marketplace where farmers connect directly with buyers for fresh, high-quality produce.
        <br />
       
       Say goodbye to middlemen and experience fair pricing, transparency, and farm-fresh goodness delivered straight to you.
      </h3>
      <br />
      <h2>
        🌾 For Farmers – List your products, track sales, and reach customers effortlessly.
      </h2>
      
      <h2>
        🛒 For Buyers – Browse fresh produce, place orders, and support local farmers.
      </h2>
    </div>
  );
}