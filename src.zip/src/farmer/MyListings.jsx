import React from 'react'

export default function MyListings() {
  return (
    <div>
      My Listings
    </div>
  )
}
