import React, { useState, useEffect } from 'react';
import axios from 'axios';
import config from '../config';
import './farmercss/salesreport.css';

const SalesReport = () => {
  const [reportData, setReportData] = useState({
    totalSales: 0,
    totalOrders: 0,
    averageOrderValue: 0,
    topSellingProducts: [],
    salesByCategory: [],
    recentTransactions: []
  });
  const [dateRange, setDateRange] = useState({
    startDate: '',
    endDate: ''
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Set default date range to last 30 days
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - 30);
    
    setDateRange({
      startDate: start.toISOString().split('T')[0],
      endDate: end.toISOString().split('T')[0]
    });
  }, []);

  useEffect(() => {
    if (dateRange.startDate && dateRange.endDate) {
      fetchSalesReport();
    }
  }, [dateRange]);

  const fetchSalesReport = async () => {
    try {
      const farmerId = localStorage.getItem('userId');
      const response = await axios.get(`${config.url}/farmer/${farmerId}/sales-report`, {
        params: {
          startDate: dateRange.startDate,
          endDate: dateRange.endDate
        }
      });
      setReportData(response.data);
      setLoading(false);
    } catch (err) {
      setError('Failed to load sales report');
      setLoading(false);
      console.error('Sales report fetch error:', err);
    }
  };

  const handleDateChange = (e) => {
    const { name, value } = e.target;
    setDateRange(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (loading) {
    return (
      <div className="sales-report-loading">
        <div className="spinner"></div>
        <p>Loading sales report...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="sales-report-error">
        <p>{error}</p>
        <button onClick={fetchSalesReport}>Retry</button>
      </div>
    );
  }

  return (
    <div className="sales-report-container">
      <div className="report-header">
        <h1>Sales Report</h1>
        <div className="date-range">
          <div className="date-input">
            <label htmlFor="startDate">Start Date</label>
            <input
              type="date"
              id="startDate"
              name="startDate"
              value={dateRange.startDate}
              onChange={handleDateChange}
            />
          </div>
          <div className="date-input">
            <label htmlFor="endDate">End Date</label>
            <input
              type="date"
              id="endDate"
              name="endDate"
              value={dateRange.endDate}
              onChange={handleDateChange}
            />
          </div>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Sales</h3>
          <p className="stat-value">₹{reportData.totalSales}</p>
        </div>
        <div className="stat-card">
          <h3>Total Orders</h3>
          <p className="stat-value">{reportData.totalOrders}</p>
        </div>
        <div className="stat-card">
          <h3>Average Order Value</h3>
          <p className="stat-value">₹{reportData.averageOrderValue}</p>
        </div>
      </div>

      <div className="report-sections">
        <div className="report-section">
          <h2>Top Selling Products</h2>
          <div className="products-list">
            {reportData.topSellingProducts.map(product => (
              <div key={product.id} className="product-item">
                <img src={product.imageUrl} alt={product.name} />
                <div className="product-info">
                  <h4>{product.name}</h4>
                  <p>Units Sold: {product.unitsSold}</p>
                  <p>Revenue: ₹{product.revenue}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="report-section">
          <h2>Sales by Category</h2>
          <div className="category-list">
            {reportData.salesByCategory.map(category => (
              <div key={category.name} className="category-item">
                <div className="category-info">
                  <h4>{category.name}</h4>
                  <p>Sales: ₹{category.sales}</p>
                </div>
                <div className="progress-bar">
                  <div 
                    className="progress" 
                    style={{ width: `${(category.sales / reportData.totalSales) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="report-section">
          <h2>Recent Transactions</h2>
          <div className="transactions-list">
            {reportData.recentTransactions.map(transaction => (
              <div key={transaction.id} className="transaction-item">
                <div className="transaction-info">
                  <h4>Order #{transaction.orderId}</h4>
                  <p>{new Date(transaction.date).toLocaleDateString()}</p>
                </div>
                <div className="transaction-details">
                  <p className="amount">₹{transaction.amount}</p>
                  <span className={`status ${transaction.status}`}>
                    {transaction.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesReport;
