import React from 'react';

export default function BuyerHome() {
  return (
    <div className="buyer-home-container">
      <div className="buyer-home-content">
        <h1 className="main-title">
          Welcome to <span className="highlight">AgroDirect</span>
          <br />
          <span className="sub-title">
            Fresh Produce, Direct from Farms to Your Doorstep!
          </span>
        </h1>
        
        <p className="intro-text">
          Welcome to a seamless marketplace where farmers connect directly with buyers for fresh, high-quality produce.
          <br />
          Say goodbye to middlemen and experience fair pricing, transparency, and farm-fresh goodness delivered straight to you.
        </p>

        <div className="sections">
          <h2 className="section-title">
            🌾 <span className="highlight">For Farmers</span> – List your products, track sales, and reach customers effortlessly.
          </h2>
          
          <h2 className="section-title">
            🛒 <span className="highlight">For Buyers</span> – Browse fresh produce, place orders, and support local farmers.
          </h2>
        </div>
      </div>
    </div>
  );
}
